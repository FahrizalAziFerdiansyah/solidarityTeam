<?php
$config=mysqli_connect("localhost","root","","map");
?>