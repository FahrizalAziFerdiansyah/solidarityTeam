<?php 
// mengaktifkan session
session_start();
 
// menghapus semua session
session_destroy();
// mengalihkan halaman sambil mengirim pesan logout

    echo "<script>
    alert('Anda berhasil keluar!');
    </script>";
    echo '<script>window.location="login.php";</script>';


?>